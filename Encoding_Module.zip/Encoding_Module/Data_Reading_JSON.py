import os
import json as js
import numpy as np
import Data_Process as DP
import Data_Input_Create as DIC
import Outline_Value as OV
def Reading_Data_JSON(Path_File_Origina): # Path_File_Origina is the Original Path
    count = 0
    File_Write_Path = './Data' # The Stored Path
    File_List = os.listdir(Path_File_Origina) # Reading the list of folders
    for num_file_json in range(len(File_List)):
        Path = Path_File_Origina + '/' + File_List[num_file_json]
        Name_List = os.listdir(Path)
        for i in range(len(Name_List)):
            List_File = [] # Empty list used to record each trajectory
            List_ID = [] # Empty list used to record each trajectory ID
            Path_File = Path + '/' + Name_List[i]  # The path of JSON file
            with open(Path_File,'r',encoding='utf8')as fp:
                json_data = js.load(fp) # Reading File
                for ID in range(len(json_data)):
                    List_ID.append(json_data[ID]['icao24']) # Collect the ID of each piece of trajectory
                List_ID_Unique = list(np.unique(List_ID)) # Remove duplicate ID
                for kk in range(len(List_ID_Unique)): # Create a list for each ID
                    List_File.append([])
                List_Index = []
                for ii in range(len(List_ID_Unique)):
                    List_Index.append(ii)
                Dic = dict(zip(List_ID_Unique, List_Index)) # Create a dictionary for each trajectory ID
                for PP in range(len(json_data)):
                    Pos_ID = Dic[json_data[PP]['icao24']]
                    List_File[Pos_ID].append(json_data[PP])
                # Save each extracted trajectory data
                for oo in range(len(List_File)):
                    List_Demo = []
                    Length = 0
                    Max_Length = 0
                    Length_QuChong = 1
                    Max_QuChong = 0
                    for YY in range(len(List_File[oo])):
                        if(str(List_File[oo][YY]['lat']) != 'None' or str(List_File[oo][YY]['lon']) != 'None' or
                           str(List_File[oo][YY]['velocity']) != 'None' or str(List_File[oo][YY]['heading']) != 'None' or
                           str(List_File[oo][YY]['vertrate']) != 'None' or str(List_File[oo][YY]['geoaltitude']) != 'None'):
                            Length += 1
                        else:
                            if(Max_Length < Length):
                                Max_Length = Length
                            Length = 0
                        if(YY >= 1):
                            if (str(List_File[oo][YY]['lat']) != str(List_File[oo][YY-1]['lat']) and str(List_File[oo][YY]['lon']) != str(List_File[oo][YY-1]['lon'])):
                                Length_QuChong += 1
                            else:
                                if(Max_QuChong < Length_QuChong):
                                    Max_QuChong = Length_QuChong
                                Length_QuChong = 1
                    if(Max_Length < Length):
                        Max_Length = Length
                    if(Max_QuChong < Length_QuChong):
                        Max_QuChong = Length_QuChong
                    if(Max_Length >= 100 and Max_QuChong >= 100):
                        for kk in range(len(List_File[oo])):
                            List_Tem = []
                            List_Tem.append(List_File[oo][kk]['time'])  # timestamp
                            List_Tem.append(List_File[oo][kk]['icao24']) # Track ID
                            List_Tem.append(List_File[oo][kk]['lat'])  # latitude
                            List_Tem.append(List_File[oo][kk]['lon'])  # longitude
                            List_Tem.append(List_File[oo][kk]['velocity']) # speed
                            List_Tem.append(List_File[oo][kk]['heading']) # heading
                            List_Tem.append(List_File[oo][kk]['vertrate'])  # vertical speed vz
                            List_Tem.append(List_File[oo][kk]['geoaltitude'])  # height
                            List_Demo.append(List_Tem)
                        List_Demo = DIC.Input_Create(DP.Data_Reading(List_Demo)) # Cleaning and intercepting data
                        # DP generates latitude and longitude velocities vy and vx based on speed and heading
                        for num_data in range(len(List_Demo)):
                            Flag = OV.Out_Value(List_Demo[num_data]) # Delete data with outliers
                            if(Flag):
                                count += 1
                                File_Write_Name = "Flight_Trac" + "_" + str(count) + ".txt"
                                Write_Path = File_Write_Path + '/' + File_Write_Name
                                File_Wri = open(Write_Path, 'w')
                                for ik in range(len(List_Demo[num_data])):
                                    File_Wri.write(str(float(List_Demo[num_data][ik][1])))
                                    File_Wri.write(' ')
                                    File_Wri.write(str(float(List_Demo[num_data][ik][2])))
                                    File_Wri.write(' ')
                                    File_Wri.write(str(int(List_Demo[num_data][ik][3])))
                                    File_Wri.write(' ')
                                    File_Wri.write(str(int(List_Demo[num_data][ik][4])))
                                    File_Wri.write(' ')
                                    File_Wri.write(str(int(List_Demo[num_data][ik][5])))
                                    File_Wri.write(' ')
                                    File_Wri.write(str(str(round(float(List_Demo[num_data][ik][6]), 1))))
                                    File_Wri.write('\n')