import Data_Reading_JSON as DRJ
import Data_Diff_Processing as DDP
import Train_Test_Split as TTS
import H5_Data_Create as HDC
# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    Path_JSON = './Opensky_Original_Data'
    DRJ.Reading_Data_JSON(Path_JSON) #  Read from raw data and store the read results in"./data"
    DDP.Diff_Computer('./Data') # Calculate the first-order difference of latitude and longitude, and store the result in './Data_Diff'
    Path_Split = './Data_Diff' # Divide the transformed data into a training set and a test set.
    TTS.Train_Test_Split(Path_Split)
    Path = './Opensky_Train_Data'
    HDC.H5_Create(Path, 50, 0.8, 'Train_Data.h5') # Obtain training data of length 50 with 80% missing values.
    Path = './Opensky_Test_Data'
    HDC.H5_Create(Path, 50, 0.8, 'Test_Data.h5') # Obtain test data of length 50 with 80% missing values.

