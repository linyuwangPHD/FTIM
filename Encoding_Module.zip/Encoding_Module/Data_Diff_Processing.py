import math
import os
import Distance

def Diff_Computer(Path): # Calculate the difference between the longitude and latitude of two adjacent points
    # The result stored in 'Data_Diff'
    File_List = os.listdir(Path)
    for i in range(len(File_List)):
        File_Path = Path + '/' + File_List[i]
        List_Diff_Weidu_Data = []
        List_Diff_Jingdu_Data = []
        List_Diff_Gaodu_Data = []
        with open(File_Path, 'r') as f:
            lines = f.readlines()
            List_Demo_weidu = []
            List_Demo_jingdu = []
            List_Demo_gaodu = []
            List_Demo_vx = []
            List_Demo_vy = []
            List_Demo_vz = []
            for line in lines:
                List_line = line.split()
                List_Demo_weidu.append(float(List_line[0]))
                List_Demo_jingdu.append(float(List_line[1]))
                List_Demo_gaodu.append(int(List_line[2]))
                List_Demo_vx.append(int(List_line[3]))
                List_Demo_vy.append(int(List_line[4]))
                List_Demo_vz.append(float(List_line[5]))
            Min = 25000
            for gaodu_index in range(len(List_Demo_gaodu)):
                if (Min > List_Demo_gaodu[gaodu_index]):
                    Min = List_Demo_gaodu[gaodu_index]
            Num_Value = int(Min / 10) * 10 - 4500    #The change in converting absolute altitude to relative altitude.
            flag = False
            for ik in range(len(List_Demo_weidu)):
                if(ik >= 1):
                    Diff_weidu = Distance.distance_2(List_Demo_weidu[ik], List_Demo_jingdu[ik], List_Demo_weidu[ik-1], List_Demo_jingdu[ik])
                    Diff_Jingdu = Distance.distance_2(List_Demo_weidu[ik],List_Demo_jingdu[ik],List_Demo_weidu[ik], List_Demo_jingdu[ik-1])
                    Diff_Gaodu = List_Demo_gaodu[ik] - List_Demo_gaodu[ik-1]
                    List_Diff_Weidu_Data.append(Diff_weidu)
                    List_Diff_Jingdu_Data.append(Diff_Jingdu)
                    List_Diff_Gaodu_Data.append(Diff_Gaodu)
                    if(int(Diff_weidu) <= 0 or int(Diff_Jingdu) <= 0):
                        flag = True
                        break
            if(flag == False):
                File_Path_Write = "./Data_Diff" + '/' + File_List[i]
                File_Wri = open(File_Path_Write, 'w')
                for jx in range(len(List_Diff_Jingdu_Data)):
                    File_Wri.write(str(int(List_Diff_Weidu_Data[jx])))
                    File_Wri.write(' ')
                    File_Wri.write(str(float(List_Demo_weidu[jx+1])))
                    File_Wri.write(' ')
                    File_Wri.write(str(int(List_Diff_Jingdu_Data[jx])))
                    File_Wri.write(' ')
                    File_Wri.write(str(float(List_Demo_jingdu[jx+1])))
                    File_Wri.write(' ')
                    File_Wri.write(str(int(int(List_Demo_gaodu[jx + 1]/10)*10-Num_Value)))
                    File_Wri.write(' ')
                    File_Wri.write(str(int(List_Demo_gaodu[jx+1])))
                    File_Wri.write(' ')
                    File_Wri.write(str(int(List_Demo_vx[jx+1])))
                    File_Wri.write(' ')
                    File_Wri.write(str(int(List_Demo_vy[jx+1])))
                    File_Wri.write(' ')
                    File_Wri.write(str(List_Demo_vz[jx+1]))
                    File_Wri.write('\n')
