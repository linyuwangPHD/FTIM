import os
import random
import shutil
def Train_Test_Split(Path):  # Divide the data into a 90% training set and a 10% test set.
    File_List = os.listdir(Path)
    Test_Number = int(len(File_List)*0.1)
    random_numbers = random.sample(range(1, len(File_List)), Test_Number)
    random_numbers = sorted(random_numbers)
    k = 0
    Train_Move = './Opensky_Train_Data'
    Test_Move = './Opensky_Test_Data'
    for i in range(len(File_List)):
        File_Path = Path + '/' + File_List[i]
        if(k < len(random_numbers) and random_numbers[k] == i):
            k += 1
            shutil.copy(File_Path, Test_Move)
        else:
            shutil.copy(File_Path, Train_Move)
