import math
from math import radians, cos, sin, sqrt, atan2
def toRadians( a):
	return a*(math.pi/180)

#return the distance of two point, unit is meter
def distance_2(latitude1, longitude1, latitude2, longitude2): # Calculate the distance between any two points
    # R is the radius of the earth in meters
    R = 6371004  #EARTH_RADIUS
    deltaLatitude = toRadians(latitude2-latitude1)
    deltaLongitude = toRadians(longitude2-longitude1)
    latitude1 =toRadians(latitude1)
    latitude2 =toRadians(latitude2)
    a = pow(math.sin(deltaLatitude/2), 2)+ math.cos(latitude1)* math.cos(latitude2)* pow(math.sin(deltaLongitude/2), 2)
    c = 2 * math.atan2(math.sqrt(a),math.sqrt(1-a))
    d = R * c
    return d
