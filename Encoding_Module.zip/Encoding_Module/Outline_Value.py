import numpy as np

def Out_Value(List_Trac): # Delete data with outliers
    List_WeiDu = []
    List_JingDu = []
    List_GaoDu = []
    List_Vx = []
    List_Vy = []
    List_Vz = []
    Flag_WeiDu = False
    Flag_JingDu = False
    Flag_GaoDu = False
    Flag_Vx = False
    Flag_Vy = False
    Flag_Vz = False
    for i in range(len(List_Trac)):
        List_WeiDu.append(float(List_Trac[i][1]))
        List_JingDu.append(float(List_Trac[i][2]))
        List_GaoDu.append(float(List_Trac[i][3]))
        List_Vx.append(float(List_Trac[i][4]))
        List_Vy.append(float(List_Trac[i][5]))
        List_Vz.append(float(List_Trac[i][6]))
    mu_weidu, std_weidu = np.mean(List_WeiDu), np.std(List_WeiDu)
    lower_weidu, upper_weidu = mu_weidu - 2 * std_weidu, mu_weidu + 2 * std_weidu # Calculate latitude range

    mu_jingdu, std_jingdu = np.mean(List_JingDu), np.std(List_JingDu)
    lower_jingdu, upper_jingdu = mu_jingdu - 2 * std_jingdu, mu_jingdu + 2 * std_jingdu # Calculate longitude range

    mu_gaodu, std_gaodu = np.mean(List_GaoDu), np.std(List_GaoDu)
    lower_gaodu, upper_gaodu = mu_gaodu - 2 * std_gaodu, mu_gaodu + 2 * std_gaodu # Calculate altitude range

    mu_vx, std_vx = np.mean(List_Vx), np.std(List_Vx)
    lower_vx, upper_vx = mu_vx - 2 * std_vx, mu_vx + 2 * std_vx # Calculate vx range

    mu_vy, std_vy = np.mean(List_Vy), np.std(List_Vy)
    lower_vy, upper_vy = mu_vy - 2 * std_vy, mu_vy + 2 * std_vy # Calculate vy range

    mu_vz, std_vz = np.mean(List_Vz), np.std(List_Vz)
    lower_vz, upper_vz = mu_vz - 2 * std_vz, mu_vz + 2 * std_vz # Calculate vz range

    for index in range(len(List_WeiDu)): # Examine each variable for the presence of outliers， z-score
        if (List_WeiDu[index] < lower_weidu or List_WeiDu[index] > upper_weidu):
            Flag_WeiDu = True
        if (List_JingDu[index] < lower_jingdu or List_JingDu[index] > upper_jingdu):
            Flag_JingDu = True
        if (List_GaoDu[index] < lower_gaodu or List_GaoDu[index] > upper_gaodu or List_GaoDu[index] < 0):
            Flag_GaoDu = True
        if (List_Vx[index] < lower_vx or List_Vx[index] > upper_vx):
            Flag_Vx = True
        if (List_Vy[index] < lower_vy or List_Vy[index] > upper_vy):
            Flag_Vy = True
        if (List_Vz[index] < lower_vz or List_Vz[index] > upper_vz):
            Flag_Vz = True
    if(Flag_WeiDu == False and Flag_JingDu == False and Flag_GaoDu == False and Flag_Vx == False and Flag_Vy == False and Flag_Vz == False):
        return True
    return False