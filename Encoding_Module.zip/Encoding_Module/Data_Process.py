import math

def Data_Reading(List_JSON): # DP generates latitude and longitude velocities vy and vx based on speed and heading
    List_Data = []
    for i in range(len(List_JSON)):
        List_Demo = []
        if (List_JSON[i][0] != 'None' and List_JSON[i][1] != 'None' and List_JSON[i][2] != 'None' and List_JSON[i][3] != 'None'
                and List_JSON[i][4] != 'None' and List_JSON[i][5] != 'None' and List_JSON[i][6] != 'None' and List_JSON[i][
                    7] != 'None' and List_JSON[i][0] != None and List_JSON[i][1] != None and List_JSON[i][2] != 'None' and List_JSON[i][3] != None
                and List_JSON[i][4] != None and List_JSON[i][5] != None and List_JSON[i][6] != None and List_JSON[i][
                    7] != None):
            List_Demo.append(List_JSON[i][0])  # Storage timestamp
            List_Demo.append(float(List_JSON[i][2]))  # Storage latitude
            List_Demo.append(float(List_JSON[i][3]))  # Store longitude
            List_Demo.append(float(List_JSON[i][7]))  # Storage height
            heading = float(List_JSON[i][5])
            Speed = float(List_JSON[i][4])
            if (heading <= 90):
                head_x = 90 - heading
                Sin_Value = math.sin(head_x * math.pi / 180)
                Cos_Value = math.cos(head_x * math.pi / 180)
                Speed_y = Speed * Sin_Value
                Speed_x = Speed * Cos_Value
            elif (heading <= 180):
                head_x = heading - 90
                Sin_Value = math.sin(head_x * math.pi / 180)
                Cos_Value = math.cos(head_x * math.pi / 180)
                Speed_y = Speed * Sin_Value * -1
                Speed_x = Speed * Cos_Value
            elif (heading <= 270):
                head_x = 270 - heading
                Sin_Value = math.sin(head_x * math.pi / 180)
                Cos_Value = math.cos(head_x * math.pi / 180)
                Speed_y = Speed * Sin_Value * -1
                Speed_x = Speed * Cos_Value * -1
            elif (heading <= 360):
                head_x = heading - 270
                Sin_Value = math.sin(head_x * math.pi / 180)
                Cos_Value = math.cos(head_x * math.pi / 180)
                Speed_y = Speed * Sin_Value
                Speed_x = Speed * Cos_Value * -1
            List_Demo.append(Speed_x)  # Velocity in the longitudinal direction
            List_Demo.append(Speed_y)  # Velocity in the latitude direction
            List_Demo.append(float(List_JSON[i][6]))  # Vertical velocity
            List_Data.append(List_Demo)
    return List_Data
