def Input_Create(List_Demo): # Cleaning and intercepting data
    Index_Start = 0
    List_Data = []
    while(Index_Start < len(List_Demo)):
        if(Index_Start + 100 >= len(List_Demo)):
            Index_Start = len(List_Demo)
            break
        Index_End = Index_Start + 100
        lines_Demo = List_Demo[Index_Start : Index_End]
        flag = False
        Index_prior = 0
        line_split_prior = []
        for line_number in range(len(lines_Demo)):
            line_split = lines_Demo[line_number]
            if(line_number == 0):
                Index_prior = int(line_split[0])
                line_split_prior = line_split
            else:
                if(int(line_split[0]) - Index_prior != 10): # The timestamp interval should be 10 seconds
                    flag = True
                    break
                if(line_split[1] == line_split_prior[1] and line_split[2] == line_split_prior[2]): # The longitude and latitude of two consecutive lines are exactly the same
                    flag = True
                    break
                Index_prior = int(line_split[0])
                line_split_prior = line_split
        if(flag == False):
            List_Data.append(lines_Demo)
            Index_Start += 60
        else:
            Index_Start += 1
    return List_Data
