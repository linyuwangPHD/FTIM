

def Sliding(List, List_Len, Window, Number, index): # List_Len 列表的长度， Window 窗口的大小， Number需要多少个数据求均值，Index需要计算值的位置
    Start = index - int(Window/2)
    End = index + int(Window/2)

    if(Start < 0):
        Start = 0 # 窗口起始位置
    if(End >= List_Len):
        End = List_Len-1 # 窗口结束位置

    Count = 0
    while(Count < Number):
        Start_Temp = Start
        End_Temp = End
        while(Start_Temp <= End_Temp):
            if(List[Start_Temp] != -1000):
                Count += 1
            Start_Temp += 1
        if(Count < Number):
            Start -= 1
            End += 1
            if (Start < 0):
                Start = 0  # 窗口起始位置
            if (End >= List_Len):
                End = List_Len - 1  # 窗口结束位置
        if(Start == 0 and End == List_Len-1):
            break
    Sum = 0
    while(Start <= End):

        if(List[Start] != -1000):
            Sum += List[Start]
        Start += 1
    return Sum/Count

'''List = [1, 2, 3, 4, 5, -1000, 6, 7, 8, 9 , 10]

A = Sliding(List, len(List), 20, 5, 5)

print(A)'''
