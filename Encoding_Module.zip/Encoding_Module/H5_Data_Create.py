import h5py
import os
import numpy as np
import math
import random
import Speed_Impute

def H5_Create(Path, Length, Percent, Name): # Path is the data path, Length is the segment length, and Percent is the percentage of missing points.

    Test_File_List = os.listdir(Path)
    Data_Missing_Train = []  # Record the training data with missing values.
    Data_Missing_Train_Label = [] # Record the labels.
    Missing_Index = []  # Record the locations of missing values.
    Value_Index = []   # Record the locations of true values.
    Original_Value = []

    for i in range(len(Test_File_List)):

        File_Path = Path + '/' + Test_File_List[i]
        f = open(File_Path, 'r')
        lines = f.readlines()

        List_Demo_weidu = []  # 纬度Label
        List_Demo_weidu_copy = []
        List_Demo_weidu_original = []

        List_Demo_jingdu = []  # 经度Label
        List_Demo_jingdu_copy = []
        List_Demo_jingdu_original = []

        List_Demo_gaodu_original = []  # 高度Label
        List_Demo_gaodu = []  # 高度Label
        List_Demo_gaodu_copy = []

        List_Demo_vx = []  # Vx Label
        List_Demo_vx_copy = []
        List_Demo_vx_copy_Impute = []

        List_Demo_vy = []  # Vy Label
        List_Demo_vy_copy = []
        List_Demo_vy_copy_Impute = []

        List_Demo_vz = []  # Vz Label
        List_Demo_vz_copy = []
        List_Demo_vz_copy_Impute = []

        for j in range(len(lines)):
            List_line = lines[j].split()
            if (j < Length):
                List_Demo_weidu.append(float(List_line[0]) / 3862)
                List_Demo_weidu_original.append(float(List_line[1]))
                List_Demo_jingdu.append(float(List_line[2]) / 4183)
                List_Demo_jingdu_original.append(float(List_line[3]))

                List_Demo_gaodu.append(float((float(List_line[4]) - 4500) / (17360 - 4500)))
                List_Demo_gaodu_original.append(float(List_line[5]))

                List_Demo_vx.append(math.fabs(float(List_line[6]) / 346))
                List_Demo_vy.append(math.fabs(float(List_line[7])) / 305)
                if (float(List_line[8]) < 0):
                    List_Demo_vz.append(float(List_line[8]) / 34.1)
                else:
                    List_Demo_vz.append(float(List_line[8]) / 30.6)
        List_Demo_weidu_copy = List_Demo_weidu.copy()
        List_Demo_jingdu_copy = List_Demo_jingdu.copy()
        List_Demo_gaodu_copy = List_Demo_gaodu.copy()
        List_Demo_vx_copy = List_Demo_vx.copy()
        List_Demo_vy_copy = List_Demo_vy.copy()
        List_Demo_vz_copy = List_Demo_vz.copy()

        WeiDu_Missing_Index = [0] * Length
        WeiDu_Value_Index = [1] * Length

        JingDu_Missing_Index = [0] * Length
        JingDu_Value_Index = [1] * Length

        GaoDu_Missing_Index = [0] * Length
        GaoDu_Value_Index = [1] * Length

        List11 = range(0, Length)
        List_Weidu = random.sample(List11, int(Length*Percent))
        List_Jingdu = random.sample(List11, int(Length*Percent))
        List_Gaodu = random.sample(List11, int(Length*Percent))
        List_Vx = random.sample(List11, int(Length*Percent))
        List_Vy = random.sample(List11, int(Length*Percent))
        List_Vz = random.sample(List11, int(Length*Percent))

        for iii in range(len(List_Weidu)):
            List_Demo_weidu_copy[List_Weidu[iii]] = 0
            WeiDu_Missing_Index[List_Weidu[iii]] = 1
            WeiDu_Value_Index[List_Weidu[iii]] = 0

            List_Demo_jingdu_copy[List_Jingdu[iii]] = 0
            JingDu_Missing_Index[List_Jingdu[iii]] = 1
            JingDu_Value_Index[List_Jingdu[iii]] = 0

            List_Demo_gaodu_copy[List_Gaodu[iii]] = 0
            GaoDu_Missing_Index[List_Gaodu[iii]] = 1
            GaoDu_Value_Index[List_Gaodu[iii]] = 0

            List_Demo_vx_copy[List_Vx[iii]] = -1000
            List_Demo_vy_copy[List_Vy[iii]] = -1000
            List_Demo_vz_copy[List_Vz[iii]] = -1000

        for impute_speed in range(Length):
            if (List_Demo_vx_copy[impute_speed] != -1000):
                List_Demo_vx_copy_Impute.append(List_Demo_vx_copy[impute_speed])
            else:
                List_Demo_vx_copy_Impute.append(
                    Speed_Impute.Sliding(List_Demo_vx_copy, len(List_Demo_vx_copy), 20, 5, impute_speed)) # 对vx进行插补

            if (List_Demo_vy_copy[impute_speed] != -1000):
                List_Demo_vy_copy_Impute.append(List_Demo_vy_copy[impute_speed])
            else:
                List_Demo_vy_copy_Impute.append(
                    Speed_Impute.Sliding(List_Demo_vy_copy, len(List_Demo_vy_copy), 20, 5, impute_speed))# 对vy进行插补

            if (List_Demo_vz_copy[impute_speed] != -1000):
                List_Demo_vz_copy_Impute.append(List_Demo_vz_copy[impute_speed])
            else:
                List_Demo_vz_copy_Impute.append(
                    Speed_Impute.Sliding(List_Demo_vz_copy, len(List_Demo_vz_copy), 20, 5, impute_speed))# 对vz进行插补

        Data_Missing_Train_Temp = []
        Data_Missing_Train_Temp.append(List_Demo_weidu_copy)
        Data_Missing_Train_Temp.append(List_Demo_vy_copy_Impute)
        Data_Missing_Train_Temp.append(List_Demo_jingdu_copy)
        Data_Missing_Train_Temp.append(List_Demo_vx_copy_Impute)
        Data_Missing_Train_Temp.append(List_Demo_gaodu_copy)
        Data_Missing_Train_Temp.append(List_Demo_vz_copy_Impute)
        Data_Missing_Train.append(Data_Missing_Train_Temp)

        Data_Missing_Train_Label_Temp = []
        Data_Missing_Train_Label_Temp.append(List_Demo_weidu)
        Data_Missing_Train_Label_Temp.append(List_Demo_jingdu)
        Data_Missing_Train_Label_Temp.append(List_Demo_gaodu)
        Data_Missing_Train_Label.append(Data_Missing_Train_Label_Temp)

        Missing_Index_Temp = []
        Missing_Index_Temp.append(WeiDu_Missing_Index)
        Missing_Index_Temp.append(JingDu_Missing_Index)
        Missing_Index_Temp.append(GaoDu_Missing_Index)
        Missing_Index.append(Missing_Index_Temp)

        Value_Index_Temp = []
        Value_Index_Temp.append(WeiDu_Value_Index)
        Value_Index_Temp.append(JingDu_Value_Index)
        Value_Index_Temp.append(GaoDu_Value_Index)
        Value_Index.append(Value_Index_Temp)

        Original_Value_Temp = []
        Original_Value_Temp.append(List_Demo_weidu_original)
        Original_Value_Temp.append(List_Demo_jingdu_original)
        Original_Value_Temp.append(List_Demo_gaodu_original)
        Original_Value.append(Original_Value_Temp)

    File_Data = h5py.File("./Train_Test_H5_Data/" + Name, "w")
    File_Data.create_dataset("Data", data=np.array(Data_Missing_Train))
    File_Data.create_dataset("Label", data=np.array(Data_Missing_Train_Label))
    File_Data.create_dataset("Missing_Index", data=np.array(Missing_Index))
    File_Data.create_dataset("Value_Index", data=np.array(Value_Index))
    File_Data.create_dataset("Original_Value", data=np.array(Original_Value))

