
# Record the reconstructed altitude.
def Impute_Gao(Pre_Gao, Label_Gao, Original_Gao, Original_Missing_Gao):
    Impute_Gao_List = []
    Label_Gao_Res = []
    Min_Gao = 100000
    for i in range(len(Original_Gao)):
        if(Original_Gao[i] < Min_Gao):
            Min_Gao = Original_Gao[i]
    Value = Min_Gao - 5000

    for i in range(len(Pre_Gao)):
        if(Original_Missing_Gao[i] != -20000):
            Impute_Gao_List.append(Label_Gao[i] +Value)
            Label_Gao_Res.append(Label_Gao[i] +Value)
        else:
            Impute_Gao_List.append(Pre_Gao[i] + Value)
            Label_Gao_Res.append(Label_Gao[i] + Value)
    return Impute_Gao_List, Label_Gao_Res