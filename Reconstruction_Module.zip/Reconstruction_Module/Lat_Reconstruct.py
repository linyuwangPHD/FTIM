import os
import numpy as np
import math
R = 6371004
# Reconstruct the latitude.
def Find_Index(Lat_List, Index): # Find the location of the original value closest to Index.
    Dis = 125
    for i in range(len(Lat_List)):
        if(Lat_List[i] != -20000):
            Temp = i - Index
            if(abs(Temp) < abs(Dis)):
                Dis = Temp
    return Index + Dis
def is_increasing(lst):
    if len(lst) <= 1:
        return True
    if(lst[0] <= lst[1]):
        return is_increasing(lst[1:])
    else:
        return False
def Deter_Direc(Lat_List): #Determine the trajectory direction, from south to north or from north to south.
    lst = []
    for i in range(len(Lat_List)):
        if(Lat_List[i] != -20000):
            lst.append(Lat_List[i]) # Collect the original latitude values.
    Flag = is_increasing(lst)
    return Flag # Set the direction from south to north as True.

def Deter(Lat_List): # Determine whether there are still positions that need to be filled.
    flag = False
    for ip in range(len(Lat_List)):
        if(Lat_List[ip] == -20000):
            flag = True
            break
    return flag
def Impute_WeiDu(Lat_List, Dis_List):
    Lat_List_Re = Lat_List.copy()
    Flag = Deter_Direc(Lat_List)  # Determine the flight direction: True for south to north, False for north to south.
    while(Deter(Lat_List_Re)): # Check whether the trajectory has been filled.
        for i in range(len(Lat_List)):
            if(Lat_List_Re[i] == -20000):
                Original_Index = Find_Index(Lat_List, i) # Find the closest original index value.
                if(Original_Index < i and Lat_List_Re[i-1] != -20000):
                    if(Flag == True): # from south to north
                        Last_Lat = Lat_List_Re[i-1]
                        Dis = Dis_List[i-1] #
                        Lat_List_Re[i] = rec_lat_from_delta_meter(Last_Lat, Dis)
                    else:
                        Last_Lat = Lat_List_Re[i-1]
                        Dis = -Dis_List[i-1] #
                        Lat_List_Re[i] = rec_lat_from_delta_meter(Last_Lat, Dis)
                if(Original_Index > i and Lat_List_Re[i+1] != -20000):
                    if(Flag == True): # from north to south
                        Last_Lat = Lat_List_Re[i+1]
                        Dis = -Dis_List[i] #
                        Lat_List_Re[i] = rec_lat_from_delta_meter(Last_Lat, Dis)
                    else:
                        Last_Lat = Lat_List_Re[i+1]
                        Dis = Dis_List[i] #
                        Lat_List_Re[i] = rec_lat_from_delta_meter(Last_Lat, Dis)
    return Lat_List_Re

def toRadians(degree):
	return degree*(math.pi/180)

def toDegree(angle):
    return angle*(180/math.pi)

def rec_lat_from_delta_meter(ori_lat,delta_lat_meter):
    return toDegree(toRadians(ori_lat) + delta_lat_meter / R)