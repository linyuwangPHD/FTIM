import h5py as h5
import numpy as np
import Lon_Reconstruct
import Lat_Reconstruct
import Alt_Reconstruct

def Re_Tra(Result_Restore, Original_Missing_Data, Label_Restore, Original_Data, Length, Number):
    Restore_Data = [] # Record the reconstructed data.
    Restore_Label = []
    for j in range(Number):
        Dis_Weidu = []
        Original_Missing_Weidu = []
        Original_Weidu = []

        Pre_Gao = []
        Original_Gao = []
        Original_Missing_Gao = []
        Label_Gao = []

        Dis_Jingdu = []
        Original_Missing_Jingdu = []
        Original_Jingdu = []

        for i in range(Length):
            Dis_Weidu.append(Result_Restore[j][0][i])
            Original_Missing_Weidu.append(Original_Missing_Data[j][0][i])
            Original_Weidu.append(Original_Data[j][0][i])

            Dis_Jingdu.append(Result_Restore[j][1][i])
            Original_Missing_Jingdu.append(Original_Missing_Data[j][1][i])
            Original_Jingdu.append(Original_Data[j][1][i])

            Pre_Gao.append(Result_Restore[j][2][i])
            Original_Gao.append(Original_Data[j][2][i])
            Original_Missing_Gao.append(Original_Missing_Data[j][2][i])
            Label_Gao.append(Label_Restore[j][2][i])
        # Reconstruct the Lat, Lon adn alt.
        Lat_Re = Lat_Reconstruct.Impute_WeiDu(Original_Missing_Weidu, Dis_Weidu)
        Lon_Re = Lon_Reconstruct.Impute_JingDu(Original_Missing_Jingdu, Dis_Jingdu, Lat_Re)
        Gao_Re, Label_Gao_Res = Alt_Reconstruct.Impute_Gao(Pre_Gao, Label_Gao, Original_Gao, Original_Missing_Gao)
        Restore_Data_Temp = []
        Restore_Data_Temp.append(Lat_Re)
        Restore_Data_Temp.append(Lon_Re)
        Restore_Data_Temp.append(Gao_Re)
        Restore_Data.append(Restore_Data_Temp)
        Restore_Label_Temp = []
        Restore_Label_Temp.append(Original_Weidu)
        Restore_Label_Temp.append(Original_Jingdu)
        Restore_Label_Temp.append(Label_Gao_Res)
        Restore_Label.append(Restore_Label_Temp)
    Restore_Data = np.array(Restore_Data)
    Restore_Label = np.array(Restore_Label)
    # Save the reconstructed data.
    File_Data = h5.File('./Final_Data/Imputation_Result.h5', "w")
    File_Data.create_dataset("Restore_Data", data=np.array(Restore_Data))
    File_Data.create_dataset("Restore_Label", data=np.array(Restore_Label))

