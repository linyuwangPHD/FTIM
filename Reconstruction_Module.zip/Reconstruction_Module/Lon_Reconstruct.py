import os
import numpy as np
import math
R = 6371004

# Reconstruct the longitude.
def rec_lon_from_delta_meter(ori_lon,ori_lat,del_lon_meter):
    return toDegree(toRadians(ori_lon) +  2 * np.arcsin(math.sin(del_lon_meter / (2 * R)) / math.cos(toRadians(ori_lat))))
def toRadians(degree):
	return degree*(math.pi/180)
def toDegree(angle):
    return angle*(180/math.pi)

def Find_Index(Lon_List, Index): # Find the position of the original value closest to Index.
    Dis = 200
    for i in range(len(Lon_List)):
        if(Lon_List[i] != -20000):
            Temp = i - Index
            if(abs(Temp) < abs(Dis)):
                Dis = Temp
    return Index + Dis

def is_increasing(lst):
    if len(lst) <= 1:
        return True
    if(lst[0] <= lst[1]):
        return is_increasing(lst[1:])
    else:
        return False
def Deter_Direc(Lat_List): # Determine the trajectory direction: increasing implies west to east.
    lst = []
    for i in range(len(Lat_List)):
        if(Lat_List[i] != -20000):
            lst.append(Lat_List[i])
    Flag = is_increasing(lst)
    return Flag

def Deter(Lon_List): # Determine whether there are still positions that need to be filled.
    flag = False
    for ip in range(len(Lon_List)):
        if(Lon_List[ip] == -20000):
            flag = True
            break
    return flag

def Impute_JingDu(Lon_List, Dis_List, Lat_List):
    Lon_List_Re = Lon_List.copy()
    Flag = Deter_Direc(Lon_List)  #Determine the flight direction: True for west to east, False for east to west.
    while(Deter(Lon_List_Re)): # Determine if the trajectory has been fully filled.
        for i in range(len(Lon_List)):
            if(Lon_List_Re[i] == -20000):
                Original_Index = Find_Index(Lon_List, i)
                if(Original_Index < i and Lon_List_Re[i-1] != -20000):
                    if(Flag == True): # From west to east.
                        Last_Lat = Lat_List[i-1]
                        Last_Lon = Lon_List_Re[i-1]
                        Dis = Dis_List[i-1] #
                        Lon_List_Re[i] = rec_lon_from_delta_meter(Last_Lon, Last_Lat, Dis)
                    else:
                        Last_Lat = Lat_List[i-1]
                        Last_Lon = Lon_List_Re[i - 1]
                        Dis = -Dis_List[i-1] #
                        Lon_List_Re[i] = rec_lon_from_delta_meter(Last_Lon, Last_Lat, Dis)
                if(Original_Index > i and Lon_List_Re[i+1] != -20000):
                    if(Flag == True): # From east to west.
                        Last_Lat = Lat_List[i+1]
                        Last_Lon = Lon_List_Re[i+1]
                        Dis = -Dis_List[i] #
                        Lon_List_Re[i] = rec_lon_from_delta_meter(Last_Lon, Last_Lat, Dis)
                    else:
                        Last_Lat = Lat_List[i + 1]
                        Last_Lon = Lon_List_Re[i + 1]
                        Dis = Dis_List[i]  #
                        Lon_List_Re[i] = rec_lon_from_delta_meter(Last_Lon, Last_Lat, Dis)
    return Lon_List_Re