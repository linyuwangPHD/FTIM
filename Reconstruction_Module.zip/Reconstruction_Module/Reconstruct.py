import h5py as h5
import numpy as np

def Recon(Path_Demo, Length, Number):
    Result_File = h5.File(Path_Demo, "r")
    Result = Result_File['Result'][:] # Reading the imputed data.
    Label = Result_File['Label'][:] #  Reading the original data labels.
    Miss_Index = Result_File['Miss_Index'][:] # Read the missing value location information.
    Original_Write_Data =Result_File['Original'][:] # Read the original data values.
    Original_Data = []
    Original_Missing_Data = []
    Result_Restore = []
    Label_Restore = []
    for i in range(Number):
        WeiDu_Original = []
        JingDu_Original = []
        GaoDu_Original = []
        for j in range(Length):
            WeiDu_Original.append(Original_Write_Data[i][0][j])
            JingDu_Original.append(Original_Write_Data[i][1][j])
            GaoDu_Original.append(Original_Write_Data[i][2][j])
        WeiDu_Missing_Data = []  # Record the original data with missing values.
        JingDu_Missing_Data = []
        GaoDu_Missing_Data = []
        Missing_Data = Miss_Index[i]
        for Miss_i in range(3): # Record the locations of missing values as -20000.
            for Miss_j in range(Length):
                if(Miss_i == 0):
                    if(Missing_Data[Miss_i][Miss_j] == 0):
                        WeiDu_Missing_Data.append(WeiDu_Original[Miss_j])
                    else:
                        WeiDu_Missing_Data.append(-20000)
                elif(Miss_i == 1):
                    if (Missing_Data[Miss_i][Miss_j] == 0):
                        JingDu_Missing_Data.append(JingDu_Original[Miss_j])
                    else:
                        JingDu_Missing_Data.append(-20000)
                else:
                    if (Missing_Data[Miss_i][Miss_j] == 0):
                        GaoDu_Missing_Data.append(GaoDu_Original[Miss_j])
                    else:
                        GaoDu_Missing_Data.append(-20000)
        Original_Data_Temp = []
        Original_Data_Temp.append(WeiDu_Original)
        Original_Data_Temp.append(JingDu_Original)
        Original_Data_Temp.append(GaoDu_Original)
        Original_Data.append(Original_Data_Temp)

        Original_Missing_Data_Temp = []
        Original_Missing_Data_Temp.append(WeiDu_Missing_Data)
        Original_Missing_Data_Temp.append(JingDu_Missing_Data)
        Original_Missing_Data_Temp.append(GaoDu_Missing_Data)
        Original_Missing_Data.append(Original_Missing_Data_Temp)

        Result_Data = Result[i]
        Result_WeiDu = []
        Result_JingDu = []
        Result_GaoDu = []

        Label_WeiDu = []
        Label_JingDu = []
        Label_GaoDu = []
        for Miss_i in range(3):
            for Miss_j in range(Length):
                if(Miss_i == 0): # Perform inverse normalization on the data.
                    Result_WeiDu.append(Result_Data[Miss_i][Miss_j]*3862)
                    Label_WeiDu.append(Label[i][Miss_i][Miss_j]*3862)
                elif(Miss_i == 1):
                    Result_JingDu.append(Result_Data[Miss_i][Miss_j]*4183)
                    Label_JingDu.append(Label[i][Miss_i][Miss_j]*4183)
                else:
                    Result_GaoDu.append(Result_Data[Miss_i][Miss_j]*12860 + 4500)
                    Label_GaoDu.append(Label[i][Miss_i][Miss_j]*12860 + 4500)
        Result_Restore_Temp = []
        Result_Restore_Temp.append(Result_WeiDu)
        Result_Restore_Temp.append(Result_JingDu)
        Result_Restore_Temp.append(Result_GaoDu)
        Result_Restore.append(Result_Restore_Temp)

        Label_Restore_Temp = []
        Label_Restore_Temp.append(Label_WeiDu)
        Label_Restore_Temp.append(Label_JingDu)
        Label_Restore_Temp.append(Label_GaoDu)
        Label_Restore.append(Label_Restore_Temp)
    Original_Data = np.array(Original_Data)
    Original_Missing_Data = np.array(Original_Missing_Data)
    Result_Restore = np.array(Result_Restore)
    Label_Restore = np.array(Label_Restore)

    return Result_Restore, Original_Missing_Data, Label_Restore, Original_Data
