import Reconstruct
import Reconstruct_Trajectory
import os
import h5py as h5

def Output_ReTra(Path, Length, Number):
    Result_Restore, Original_Missing_Data, Label_Restore, Original_Data = Reconstruct.Recon(Path, Length, Number)
    # Reconstruct trajectory.
    Reconstruct_Trajectory.Re_Tra(Result_Restore, Original_Missing_Data, Label_Restore, Original_Data, Length, Number)

if __name__ == '__main__':
    List = os.listdir("./Result_Write/") # Read the imputed data.
    for i in range(len(List)):
        print("%%%%%%%%%%%%%%%%%%%%%%")
        print(List[i])
        Path = "./Result_Write/" + List[i]
        Result_File = h5.File(Path, "r")
        Result = Result_File['Result'][:]
        Length = Result.shape[2] # The length of each trajectory segment.
        Number = Result.shape[0] # The number of trajectory segment.
        Output_ReTra(Path, Length, Number)

