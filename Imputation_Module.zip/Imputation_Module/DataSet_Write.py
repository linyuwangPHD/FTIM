from torch.utils.data import Dataset

class subDataset(Dataset):
    def __init__(self, Data, Lable, Miss_Index, Value_Index, Original_Gaodu):
        self.Data = Data
        self.Lable = Lable
        self.Miss_Index = Miss_Index
        self.Value_Index = Value_Index
        self.Original_Gaodu = Original_Gaodu
    def __len__(self):
        return len(self.Data)

    def __getitem__(self, index):
        data= self.Data[index]
        label = self.Lable[index]
        miss_index = self.Miss_Index[index]
        value_index = self.Value_Index[index]
        original_Gaodu = self.Original_Gaodu[index]
        return data, label, miss_index, value_index, original_Gaodu
