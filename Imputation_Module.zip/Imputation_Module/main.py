import Model_Train
import Prediction_Rewrite

if __name__ == '__main__':
    Path_Train = './Train_Test_H5_Data/Train_Data.h5'   # The path of the training set.
    Path_Test = './Train_Test_H5_Data/Test_Data.h5'     # The path of the test set.
    Model_Saved_Path = './Model_Saved/Model_U_Net.mkl'  # Model save path.
    Model_Train.Model_Train(Path_Train, Path_Test, Model_Saved_Path)  # Train and test the model.
    Path_Write = './Result_Write/Result.h5'  # Result save path.
    Prediction_Rewrite.Result_Write(Path_Test, Model_Saved_Path, Path_Write) # Use the saved model to predict the test set results and save them.

