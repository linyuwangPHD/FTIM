import h5py as h5
import numpy as np
import torch
from torch.utils.data import DataLoader
import DataSet_Write
import U_Net_Model
from torch.autograd import Variable

def Result_Write(Path_Test, Path_Model, Path_Write):
    Data_Test_File = h5.File(Path_Test, "r") # Reading the test data.
    Test_Data = Data_Test_File['Data'][:] # Input Data
    Test_Label = Data_Test_File['Label'][:] # Label
    Test_Miss_Index_Data = Data_Test_File['Missing_Index'][:]
    Test_Value_Index_Data = Data_Test_File['Value_Index'][:]
    Test_Original_Gaodu = Data_Test_File["Original_Value"][:]
    Test_Data = torch.from_numpy(np.array(Test_Data)).float()
    Test_Label = torch.from_numpy(np.array(Test_Label)).float()
    Test_Miss_Index_Data = torch.from_numpy(np.array(Test_Miss_Index_Data)).float()
    Test_Value_Index_Data = torch.from_numpy(np.array(Test_Value_Index_Data)).float()
    Test_Original_Gaodu = torch.from_numpy(np.array(Test_Original_Gaodu)).float()
    Test_Data_Merge = DataSet_Write.subDataset(Test_Data, Test_Label, Test_Miss_Index_Data, Test_Value_Index_Data, Test_Original_Gaodu)
    Test_Loader = DataLoader(Test_Data_Merge, 128, shuffle=False, num_workers=0)
    Path_Writh =  Path_Model  # Model Path
    Model = U_Net_Model.Moudle()
    Model.load_state_dict(torch.load(Path_Writh)) # Load the recorded model.
    if(torch.cuda.is_available()):
        Model = Model.cuda()
    critertion =  torch.nn.MSELoss(reduction='sum')
    Result = []
    Lable = []
    Miss_Index_Write = []
    Original = []
    Data_Test_All = []
    Model.eval()
    with torch.no_grad():
        loss_total = 0
        ii = 0
        for i_test, item_test in enumerate(Test_Loader):
            print(i_test)
            Data_test, Label_test, miss_index, value_index, Original_Gaodu = item_test
            Data_test = Variable(Data_test)
            Label_test = Variable(Label_test)
            miss_index = Variable(miss_index)
            value_index = Variable(value_index)
            Original_Gaodu = Variable(Original_Gaodu)
            Data_test = Data_test.cuda()
            Label_test = Label_test.cuda()
            miss_index = miss_index.cuda()
            value_index = value_index.cuda()
            Original_Gaodu = Original_Gaodu.cuda()
            out_test = Model(Data_test)
            loss_value_test = critertion(out_test*miss_index, Label_test*miss_index)
            loss_total += loss_value_test.data.item() /miss_index.sum()
            Out_Rewrite = (out_test*miss_index + Label_test*value_index).cpu().numpy()
            Label_Write = Label_test.cpu().numpy()
            Miss_Write = miss_index.cpu().numpy()
            Original_Write = Original_Gaodu.cpu().numpy()
            Data_test_write = Data_test.cpu().numpy()
            for io in range(out_test.shape[0]):
                Result.append(Out_Rewrite[io])
                Lable.append(Label_Write[io])
                Miss_Index_Write.append(Miss_Write[io])
                Original.append(Original_Write[io])
                Data_Test_All.append(Data_test_write[io])
            ii += 1
    Result = np.array(Result)
    Lable = np.array(Lable)
    Miss_Index_Write = np.array(Miss_Index_Write) # Record the prediction results.
    Original = np.array(Original)
    File_Data = h5.File(Path_Write, "w")
    File_Data.create_dataset("Result", data=np.array(Result))
    File_Data.create_dataset("Label", data=np.array(Lable))
    File_Data.create_dataset("Miss_Index", data=np.array(Miss_Index_Write))
    File_Data.create_dataset("Original", data=np.array(Original))