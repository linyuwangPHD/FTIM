import h5py as h5
import numpy as np
import torch
from torch.utils.data import DataLoader
import DataSet
import U_Net_Model
from torch.autograd import Variable
import torch.optim as opt

def Model_Train(Train_Path, Test_Path, Model_Saved_Path):
    # Train_Path: Training set path; Test_Path: Test set path; Model_Saved_Path: Model save path.
    Data_Train_File = h5.File(Train_Path, "r")  # Load the training dataset.
    Data_Test_File = h5.File(Test_Path, "r")    # Load the testing dataset.

    Train_Data = Data_Train_File['Data'][:] # Train trajectory data.
    Train_Label = Data_Train_File['Label'][:] # training data labels
    Train_Miss_Index_Data = Data_Train_File['Missing_Index'][:]
    Train_Value_Index_Data = Data_Train_File['Value_Index'][:]
    Train_Data = torch.from_numpy(np.array(Train_Data)).float()
    Train_Label = torch.from_numpy(np.array(Train_Label)).float()
    Train_Miss_Index_Data = torch.from_numpy(np.array(Train_Miss_Index_Data)).float()
    Train_Value_Index_Data = torch.from_numpy(np.array(Train_Value_Index_Data)).float()

    Test_Data = Data_Test_File['Data'][:] #  Train trajectory data.
    Test_Label = Data_Test_File['Label'][:] # training data labels
    Test_Miss_Index_Data = Data_Test_File['Missing_Index'][:]
    Test_Value_Index_Data = Data_Test_File['Value_Index'][:]
    Test_Data = torch.from_numpy(np.array(Test_Data)).float()
    Test_Label = torch.from_numpy(np.array(Test_Label)).float()
    Test_Miss_Index_Data = torch.from_numpy(np.array(Test_Miss_Index_Data)).float()
    Test_Value_Index_Data = torch.from_numpy(np.array(Test_Value_Index_Data)).float()
    # batch size is 64
    Train_Data_Merge = DataSet.subDataset(Train_Data,Train_Label, Train_Miss_Index_Data, Train_Value_Index_Data)
    Train_Loader = DataLoader(Train_Data_Merge, 64, shuffle=True, num_workers=0)
    Test_Data_Merge = DataSet.subDataset(Test_Data,Test_Label, Test_Miss_Index_Data, Test_Value_Index_Data)
    Test_Loader = DataLoader(Test_Data_Merge, 64, shuffle=False, num_workers=0)
    Path_Writh = Model_Saved_Path
    Model = U_Net_Model.Moudle()
    if(torch.cuda.is_available()):
        Model = Model.cuda()
    critertion = torch.nn.MSELoss(reduction='sum')
    optimer = opt.Adam(Model.parameters(), lr = 0.00001)  # Set the learning rate to 0.00001.
    total_step = len(Train_Loader)
    def update_lr(optimizer, lr):
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
    curr_lr = 0.00001
    Test_Loss = 0.1
    for j in range(100):
        Model.eval()  # Test  model performance.
        with torch.no_grad():
            total = 0
            loss_total = 0
            ii = 0
            for i_test, item_test in enumerate(Test_Loader):
                Data_test, Label_test, Miss_Index_test, Value_Index_test = item_test
                Data_test = Variable(Data_test)
                Label_test = Variable(Label_test)
                Miss_Index_test = Variable(Miss_Index_test)
                Value_Index_test = Variable(Value_Index_test)

                Data_test = Data_test.cuda()
                Label_test = Label_test.cuda()
                Miss_Index_test = Miss_Index_test.cuda()
                Value_Index_test = Value_Index_test.cuda()

                out_test = Model(Data_test)
                loss_value_test = critertion(out_test*Miss_Index_test, Label_test*Miss_Index_test)
                loss_total += loss_value_test.data.item()/Miss_Index_test.sum()
                ii += 1
            if(loss_total / ii < Test_Loss):
                Test_Loss = loss_total / ii
                torch.save(Model.state_dict(), Path_Writh)  #保存模型
            print('Loss of Test Data:{}'.format(loss_total / ii))
        Model.train()  # Train the model.
        for i, item in enumerate(Train_Loader):
            Data_Train, Label, Miss_Index_Train, Value_Index_Train = item
            Data_Train = Variable(Data_Train)
            Label = Variable(Label)
            Miss_Index_Train = Variable(Miss_Index_Train)
            Value_Index_Train = Variable(Value_Index_Train)
            Data_Train = Data_Train.cuda()
            Label = Label.cuda()
            Miss_Index_Train = Miss_Index_Train.cuda()
            Value_Index_Train = Value_Index_Train.cuda()
            out = Model(Data_Train)
            loss_value = critertion(out*Miss_Index_Train, Label*Miss_Index_Train)/Miss_Index_Train.sum() # 计算损失值
            optimer.zero_grad()
            loss_value.backward()  # 反向传播
            optimer.step()
            if(i % 100 == 0 or i == total_step):
                print(('Epoch:[{}/{}], Step[{}/{}], loss:{:.4f}, Accuracy:{:.4f}'.format(j + 1, 100, i, total_step, loss_value.data.item(), 0.0)))

        curr_lr = curr_lr * 0.9
        update_lr(optimer, curr_lr)



