import torch
import torch.nn as nn
class Moudle(nn.Module):
    def __init__(self):
        super(Moudle, self).__init__()
        #Embedding
        self.Input_Embedding = nn.Sequential(
            nn.Conv1d(in_channels=6, out_channels=48, kernel_size=3, stride=1, padding=1, groups=3),
            nn.Dropout(p=0.1),
            nn.ReLU()
         )
        # The first downsampling.
        self.First_Down = nn.Sequential(
            nn.BatchNorm1d(48),
            nn.Conv1d(in_channels=48, out_channels=96, kernel_size=3, stride=2, padding=1, groups=3),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )
        # The secondary downsampling.
        self.Secondary_Down = nn.Sequential(
            nn.BatchNorm1d(96),
            nn.Conv1d(in_channels=96, out_channels=192, kernel_size=3, stride=2, padding=1, groups=3),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )
        # The third downsampling.
        self.Third_Down = nn.Sequential(
            nn.BatchNorm1d(192),
            nn.Conv1d(in_channels=192, out_channels=384, kernel_size=3, stride=2, padding=1, groups=3),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )
        # The  fourth downsampling.
        self.Fourth_Down = nn.Sequential(
            nn.BatchNorm1d(384),
            nn.Conv1d(in_channels=384, out_channels=768, kernel_size=2, stride=2, groups=3),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )

        # The transitional part.
        self.Double_Net = nn.Sequential(
            nn.BatchNorm1d(768),
            nn.Conv1d(in_channels=768, out_channels=768, kernel_size=3, stride=1, padding=1, groups=1),
            nn.Dropout(p=0.1),
            nn.ReLU()
        )


        # The  first upsampling
        self.ConvT_1_Up = nn.Sequential(
            nn.BatchNorm1d(768),
            torch.nn.ConvTranspose1d(in_channels=768, out_channels=384, kernel_size=3, stride=2, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )

        # Merge the output results of the third downsampling.
        self.UP_1_Conv_1 = nn.Sequential(
            nn.BatchNorm1d(768),
            torch.nn.Conv1d(in_channels=768, out_channels=384, kernel_size=3, stride=1, padding=1, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )
        self.UP_1_Conv_2 = torch.nn.Conv1d(in_channels=384, out_channels=192, kernel_size=3, stride=1, padding=1, groups=1)
        self.UP_1_Conv_Extra = torch.nn.Conv1d(in_channels=768, out_channels=192, kernel_size=3, stride=1, padding=1, groups=1)
        self.Up_1_Dropout = nn.Dropout(0.1)
        self.Up_1_Relu = nn.ReLU()

        # The  secondary upsampling
        self.ConvT_2_Up = nn.Sequential(
            nn.BatchNorm1d(192),
            torch.nn.ConvTranspose1d(in_channels=192, out_channels=192, kernel_size=3, stride=2, padding=1, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )
        # Merge the output results of the second downsampling.
        self.UP_2_Conv_1 = nn.Sequential(
            nn.BatchNorm1d(384),
            torch.nn.Conv1d(in_channels=384, out_channels=192, kernel_size=3, stride=1, padding=1, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )
        self.UP_2_Conv_2 = torch.nn.Conv1d(in_channels=192, out_channels=96, kernel_size=3, stride=1, padding=1, groups=1)
        self.UP_2_Conv_Extra = torch.nn.Conv1d(in_channels=384, out_channels=96, kernel_size=3, stride=1, padding=1, groups=1)
        self.Up_2_Dropout = nn.Dropout(0.1)
        self.Up_2_Relu = nn.ReLU()

        # The third upsampling
        self.ConvT_3_Up = nn.Sequential(
            nn.BatchNorm1d(96),
            torch.nn.ConvTranspose1d(in_channels=96, out_channels=96, kernel_size=3, stride=2, padding=1, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )

        # Merge the output results of the first downsampling.
        self.UP_3_Conv_1 = nn.Sequential(
            nn.BatchNorm1d(192),
            torch.nn.Conv1d(in_channels=192, out_channels=96, kernel_size=3, stride=1, padding=1, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )
        self.UP_3_Conv_2 = torch.nn.Conv1d(in_channels=96, out_channels=48, kernel_size=3, stride=1, padding=1, groups=1)
        self.UP_3_Conv_Extra = torch.nn.Conv1d(in_channels=192, out_channels=48, kernel_size=3, stride=1, padding=1, groups=1)
        self.Up_3_Dropout = nn.Dropout(0.1)
        self.Up_3_Relu = nn.ReLU()

        # The Fourth upsampling
        self.ConvT_4_Up = nn.Sequential(
            nn.BatchNorm1d(48),
            torch.nn.ConvTranspose1d(in_channels=48, out_channels=48, kernel_size=2, stride=2, groups=1),
            nn.Dropout(0.1),
            nn.ReLU()
        )
        # Fully connected neural network
        self.DNN_Out = nn.Sequential(
            nn.Linear(96, 512),
            nn.Dropout(p=0.2),
            nn.ReLU(),
            nn.Linear(512, 128),
            nn.Dropout(p=0.2),
            nn.ReLU(),
            nn.Linear(128, 3),
            nn.Sigmoid()
        )
    def forward(self, Data):
        # PatchEmbedding
        Embedd_Data = self.Input_Embedding(Data)
        First_Down = self.First_Down(Embedd_Data)
        Secondary_Down = self.Secondary_Down(First_Down)
        Third_Down = self.Third_Down(Secondary_Down)
        Fourth_Down = self.Fourth_Down(Third_Down)
        Embedd_Data = Embedd_Data.permute(0, 2, 1)
        First_Down = First_Down.permute(0, 2, 1)
        Secondary_Down = Secondary_Down.permute(0, 2, 1)
        Third_Down = Third_Down.permute(0, 2, 1)
        Fourth_Down = Fourth_Down.permute(0, 2, 1)
        #transition part
        Trans_Fourth = Fourth_Down.permute(0, 2, 1)
        Encoder_Decoder = self.Double_Net(Trans_Fourth)
        # The  first upsampling
        First_Up = self.ConvT_1_Up(Encoder_Decoder)
        First_Up_Merge = torch.cat((First_Up, Third_Down.permute(0, 2, 1)), 1)
        First_Up_Conv1 = self.UP_1_Conv_1(First_Up_Merge)
        First_Up_Cinv2 = self.UP_1_Conv_2(First_Up_Conv1)
        First_Up_Extra = self.UP_1_Conv_Extra(First_Up_Merge)
        First_Up_Out = First_Up_Cinv2 + First_Up_Extra
        First_Up_Out = self.Up_1_Dropout(First_Up_Out)
        First_Up_Out = self.Up_1_Relu(First_Up_Out)
        # The secondary upsampling
        Secondary_Up = self.ConvT_2_Up(First_Up_Out)
        Secondary_Up_Merge = torch.cat((Secondary_Up, Secondary_Down.permute(0, 2, 1)), 1)
        Secondary_Up_Conv1 = self.UP_2_Conv_1(Secondary_Up_Merge)
        Secondary_Up_Conv2 = self.UP_2_Conv_2(Secondary_Up_Conv1)
        Secondary_Up_Extra = self.UP_2_Conv_Extra(Secondary_Up_Merge)
        Secondary_Up_Out = Secondary_Up_Conv2 + Secondary_Up_Extra
        Secondary_Up_Out = self.Up_2_Dropout(Secondary_Up_Out)
        Secondary_Up_Out = self.Up_2_Relu(Secondary_Up_Out)
        # The third upsampling
        Third_Up = self.ConvT_3_Up(Secondary_Up_Out)
        Third_Up_Merge = torch.cat((Third_Up, First_Down.permute(0, 2, 1)), 1)
        Third_Up_Conv1 = self.UP_3_Conv_1(Third_Up_Merge)
        Third_Up_Conv2 = self.UP_3_Conv_2(Third_Up_Conv1)
        Third_Up_Extra = self.UP_3_Conv_Extra(Third_Up_Merge)
        Third_Up_Out = Third_Up_Conv2 + Third_Up_Extra
        Third_Up_Out = self.Up_3_Dropout(Third_Up_Out)
        Third_Up_Out = self.Up_3_Relu(Third_Up_Out)
        #The fourth upsampling
        Fourth_Up = self.ConvT_4_Up(Third_Up_Out)
        Fourth_Up_Merge = torch.cat((Fourth_Up, Embedd_Data.permute(0, 2, 1)), 1)
        DNN_Step = Fourth_Up_Merge.permute(0, 2, 1)
        Final_Out = self.DNN_Out(DNN_Step)
        return  Final_Out.permute(0, 2, 1)







